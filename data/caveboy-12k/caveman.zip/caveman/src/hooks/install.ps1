# caveman — one-command hook installer for Claude Code (Windows PowerShell)
# Installs: SessionStart hook (auto-load rules) + UserPromptSubmit hook (mode tracking)
# Usage: powershell -ExecutionPolicy Bypass -File src\hooks\install.ps1
#   or:  powershell -ExecutionPolicy Bypass -File src\hooks\install.ps1 -Force
#   or (remote, no -Force support via pipe):
#        irm https://raw.githubusercontent.com/JuliusBrussee/caveman/main/src/hooks/install.ps1 | iex
#   Note: irm ... | iex cannot pass -Force. For force reinstall, save the file and run with -File.
param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# Require node
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: 'node' is required to install the caveman hooks (used to merge" -ForegroundColor Red
    Write-Host "       the hook config into settings.json safely)." -ForegroundColor Red
    Write-Host "       Install Node.js from https://nodejs.org and re-run this script." -ForegroundColor Red
    exit 1
}

$ClaudeDir = if ($env:CLAUDE_CONFIG_DIR) { $env:CLAUDE_CONFIG_DIR } else { Join-Path $env:USERPROFILE ".claude" }
$HooksDir = Join-Path $ClaudeDir "hooks"
$Settings = Join-Path $ClaudeDir "settings.json"
$RepoUrl = "https://raw.githubusercontent.com/JuliusBrussee/caveman/main/src/hooks"

$HookFiles = @("package.json", "caveman-config.js", "caveman-parse.js", "caveman-activate.js", "caveman-mode-tracker.js", "caveman-stats.js", "caveman-statusline.sh", "caveman-statusline.ps1", "cavecrew-model-overrides.js")

# Resolve source — works from repo clone or remote
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { $null }

# Use the unified JSONC parser when running from a clone. Standalone copies
# refuse unreadable settings before copying hooks or replacing existing files.
$SettingsHelper = ""
if ($ScriptDir) {
    $candidate = Join-Path $ScriptDir "../../bin/lib/settings.js"
    if (Test-Path -LiteralPath $candidate) { $SettingsHelper = $candidate }
}
$env:CAVEMAN_SETTINGS = $Settings
$env:CAVEMAN_HOOKS_DIR = $HooksDir
$env:CAVEMAN_SETTINGS_HELPER = $SettingsHelper
@'
const fs = require('fs');
try {
  const manifest = process.env.CAVEMAN_HOOKS_DIR + '/package.json';
  if (fs.existsSync(manifest)) {
    const value = JSON.parse(fs.readFileSync(manifest, 'utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value) || (value.type !== undefined && value.type !== 'commonjs')) {
      throw new Error('existing hooks/package.json is incompatible with CommonJS hooks');
    }
  }
  const file = process.env.CAVEMAN_SETTINGS;
  if (fs.existsSync(file)) {
    const helper = process.env.CAVEMAN_SETTINGS_HELPER;
    const value = helper ? require(helper).readSettings(file) : JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('settings.json must be a readable object');
  }
} catch (error) {
  console.error('Cannot install standalone hooks: ' + error.message);
  console.error('Nothing was changed. For JSONC settings, use bin/install.js from a clone.');
  process.exit(1);
}
'@ | node --input-type=commonjs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

# Check if already installed (unless -Force). Older installs only had two hook
# files, so require the full current set plus the hook registrations before we
# short-circuit.
if (-not $Force) {
    $AllFilesPresent = $true
    foreach ($hook in $HookFiles) {
        if (-not (Test-Path (Join-Path $HooksDir $hook))) {
            $AllFilesPresent = $false
            break
        }
    }

    $HooksWired = $false
    $HasStatusLine = $false
    if ($AllFilesPresent -and (Test-Path $Settings)) {
        try {
            $settingsObj = Get-Content $Settings -Raw | ConvertFrom-Json
            # Probe for the exact script we wire for this event, not a bare
            # 'caveman' substring — that also matches user hooks merely
            # mentioning the word in a path (#593), which made us skip wiring
            # and silently leave caveman inactive. Mirrors install.sh.
            $hasCavemanHook = {
                param([string]$eventName, [string]$script)
                if (-not $settingsObj.hooks) { return $false }
                $entries = $settingsObj.hooks.$eventName
                if (-not $entries) { return $false }
                foreach ($entry in $entries) {
                    if ($entry.hooks) {
                        foreach ($hookDef in $entry.hooks) {
                            if ($hookDef.command -and $hookDef.command.Contains($script)) {
                                return $true
                            }
                        }
                    }
                }
                return $false
            }
            $HooksWired = (& $hasCavemanHook "SessionStart" "caveman-activate.js") `
                -and (& $hasCavemanHook "UserPromptSubmit" "caveman-mode-tracker.js")
            $HasStatusLine = $null -ne $settingsObj.statusLine
        } catch {
            $HooksWired = $false
            $HasStatusLine = $false
        }
    }

    if ($AllFilesPresent -and $HooksWired -and $HasStatusLine) {
        Write-Host "Caveman hooks already installed in $HooksDir"
        Write-Host "  Re-run with -Force to overwrite: powershell -File hooks\install.ps1 -Force"
        Write-Host ""
        Write-Host "Nothing to do. Hooks are already in place."
        exit 0
    }
}

if ($Force -and (Test-Path (Join-Path $HooksDir "caveman-activate.js"))) {
    Write-Host "Reinstalling caveman hooks (-Force)..."
} else {
    Write-Host "Installing caveman hooks..."
}

# 1. Ensure hooks dir exists
if (-not (Test-Path $HooksDir)) {
    New-Item -ItemType Directory -Path $HooksDir -Force | Out-Null
}

# 2. Copy or download hook files
foreach ($hook in $HookFiles) {
    $dest = Join-Path $HooksDir $hook
    if ($hook -eq "package.json" -and (Test-Path -LiteralPath $dest)) {
        Write-Host "  Preserved existing: $dest"
        continue
    }
    $localSource = if ($ScriptDir) { Join-Path $ScriptDir $hook } else { $null }

    if ($localSource -and (Test-Path $localSource)) {
        Copy-Item $localSource $dest -Force
    } else {
        Invoke-WebRequest -Uri "$RepoUrl/$hook" -OutFile $dest -UseBasicParsing
    }
    Write-Host "  Installed: $dest"
}

# 3. Wire hooks + statusline into settings.json (idempotent)
if (-not (Test-Path $Settings)) {
    Set-Content -Path $Settings -Value "{}"
}

# Back up existing settings.json before touching it. Back up ONCE: without the
# Test-Path guard a -Force reinstall overwrites the only pre-caveman copy with
# the already-merged file, destroying the user's recovery path. Same guard as
# bin/install.js.
if (-not (Test-Path "$Settings.bak")) {
    Copy-Item $Settings "$Settings.bak"
}

# Use node for safe JSON merging — pass paths via env vars to avoid injection
# if the username contains a single quote (e.g., O'Brien).
# Use a single-quote here-string so PowerShell does NOT expand $variables inside.
$env:CAVEMAN_SETTINGS = $Settings -replace '\\', '/'
$env:CAVEMAN_HOOKS_DIR = $HooksDir -replace '\\', '/'

$nodeScript = @'
const fs = require('fs');
const settingsPath = process.env.CAVEMAN_SETTINGS;
const hooksDir = process.env.CAVEMAN_HOOKS_DIR;
const managedStatusLinePath = hooksDir + '/caveman-statusline.ps1';
const shared = process.env.CAVEMAN_SETTINGS_HELPER ? require(process.env.CAVEMAN_SETTINGS_HELPER) : null;
const meta = {};
const settings = shared ? shared.readSettings(settingsPath, meta) : JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
if (!settings || typeof settings !== 'object' || Array.isArray(settings)) throw new Error('settings.json must be a readable object');
if (meta.jsonc) console.log('  Comments are preserved in ' + settingsPath + '.bak; updated settings use JSON.');
if (!settings.hooks) settings.hooks = {};

// SessionStart
if (!settings.hooks.SessionStart) settings.hooks.SessionStart = [];
// Match the exact script, not a bare 'caveman' substring — that also matches
// user hooks merely mentioning the word in a path (#593), which made us skip
// wiring and silently leave caveman inactive.
const hasStart = settings.hooks.SessionStart.some(e =>
  e.hooks && e.hooks.some(h => h.command && h.command.includes('caveman-activate.js'))
);
if (!hasStart) {
  settings.hooks.SessionStart.push({
    hooks: [{
      type: 'command',
      command: 'node "' + hooksDir + '/caveman-activate.js"',
      timeout: 30,
      statusMessage: 'Loading caveman mode...'
    }]
  });
}

// UserPromptSubmit
if (!settings.hooks.UserPromptSubmit) settings.hooks.UserPromptSubmit = [];
const hasPrompt = settings.hooks.UserPromptSubmit.some(e =>
  e.hooks && e.hooks.some(h => h.command && h.command.includes('caveman-mode-tracker.js'))
);
if (!hasPrompt) {
  settings.hooks.UserPromptSubmit.push({
    hooks: [{
      type: 'command',
      command: 'node "' + hooksDir + '/caveman-mode-tracker.js"',
      timeout: 30,
      statusMessage: 'Tracking caveman mode...'
    }]
  });
}

// Statusline
if (!settings.statusLine) {
  settings.statusLine = {
    type: 'command',
    command: 'powershell -ExecutionPolicy Bypass -File "' + managedStatusLinePath + '"'
  };
  console.log('  Statusline badge configured.');
} else {
  const cmd = typeof settings.statusLine === 'string'
    ? settings.statusLine
    : (settings.statusLine.command || '');
  if (cmd.includes(managedStatusLinePath)) {
    console.log('  Statusline badge already configured.');
  } else {
    console.log('  NOTE: Existing statusline detected - caveman badge NOT added.');
    console.log('        See src/hooks/README.md to add the badge to your existing statusline.');
  }
}

if (shared) shared.writeSettings(settingsPath, settings);
else fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2) + '\n');
console.log('  Hooks wired in settings.json');
'@

$tmpScript = Join-Path $env:TEMP "caveman-install-$([System.Diagnostics.Process]::GetCurrentProcess().Id).js"
try {
    [System.IO.File]::WriteAllText($tmpScript, $nodeScript, [System.Text.Encoding]::UTF8)
    node $tmpScript
    $MergeExitCode = $LASTEXITCODE
} finally {
    if (Test-Path $tmpScript) { Remove-Item $tmpScript -Force }
}
if ($MergeExitCode -ne 0) {
    Write-Host "Hook settings could not be updated; installation did not complete." -ForegroundColor Red
    exit $MergeExitCode
}

Write-Host ""
Write-Host "Done! Restart Claude Code to activate." -ForegroundColor Green
Write-Host ""
Write-Host "What's installed:"
Write-Host "  - SessionStart hook: auto-loads caveman rules every session"
Write-Host "  - Mode tracker hook: updates statusline badge when you switch modes"
Write-Host "    (/caveman lite, /caveman ultra, /caveman-commit, etc.)"
Write-Host "  - Statusline badge: shows [CAVEMAN] or [CAVEMAN:ULTRA] etc."
