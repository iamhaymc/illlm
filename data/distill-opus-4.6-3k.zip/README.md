---
license: apache-2.0
---

> [!WARNING] NOTICE: The original dataset has been updated with better filtering. Please use the original dataset, not this one.
> 

Filtered from: https://huggingface.co/datasets/crownelius/Opus-4.6-Reasoning-3000x

The original dataset has 979 refusals, I removed these in this version.